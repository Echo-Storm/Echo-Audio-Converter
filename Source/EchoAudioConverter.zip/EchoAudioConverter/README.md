# Echo Audio Converter

Batch audio format converter with automatic FFmpeg management.

## Features

- **Batch Processing** - Queue multiple files, convert all at once
- **Metadata Preservation** - Artist, album, title, etc. copied to output
- **Album Art** - Preserved for formats that support it (FLAC, M4A, MP3)
- **Format Support** - MP3, FLAC, WAV, AAC, OGG, OPUS, M4A, ALAC
- **FFmpeg Auto-Update** - Downloads from gyan.dev
- **Drag & Drop** - Files or folders
- **Duplicate Detection** - Won't queue the same file twice

## Installation

```
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
python echo_audio_converter.py
```

Click **Download FFmpeg** on first run.

## Usage

1. Add files (button, drag & drop, or folder)
2. Select output format and quality
3. Click **Convert All**
4. Right-click or Delete key to remove queue items

Log saved to `EAC_Log.txt` in app folder.

## Metadata Notes

- `-map_metadata 0` copies all tags from input
- Album art preserved for: FLAC, M4A/AAC, MP3, ALAC
- Album art stripped for: WAV, OGG, OPUS (format limitations)
