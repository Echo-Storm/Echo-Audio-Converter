@echo off
title Echo Audio Converter
cd /d "%~dp0"

:: Check if venv exists, create and install if not
if not exist "venv\Scripts\python.exe" (
    echo Creating virtual environment...
    python -m venv venv
    if errorlevel 1 (
        echo ERROR: Failed to create virtual environment.
        echo Make sure Python 3.10+ is installed and in PATH.
        pause
        exit /b 1
    )
)

:: Always run pip install so existing venvs pick up any new or updated dependencies
venv\Scripts\pip.exe install -r requirements.txt --quiet
if errorlevel 1 (
    echo ERROR: Failed to install dependencies.
    pause
    exit /b 1
)

:: Launch the app
venv\Scripts\python.exe echo_audio_converter.py
