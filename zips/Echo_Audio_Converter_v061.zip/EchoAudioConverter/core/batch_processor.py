"""
Batch processing queue for Echo Audio Converter.
"""

import os
import uuid
from pathlib import Path
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional, List
from datetime import datetime


class JobStatus(Enum):
    PENDING = "pending"
    CONVERTING = "converting"
    COMPLETE = "complete"
    FAILED = "failed"
    CANCELLED = "cancelled"


@dataclass
class ConversionJob:
    id: str
    input_path: str
    output_path: str
    format_name: str
    quality_option: str
    base_dir: Optional[str] = None  # For relative path display when loading from subdirs
    loudness_target: Optional[float] = None  # Target LUFS for normalization (e.g., -14.0)
    # Source file info (populated from ffprobe)
    source_format: Optional[str] = None  # e.g., "FLAC", "MP3"
    source_bitrate: Optional[int] = None  # bits per second
    source_duration: Optional[float] = None  # seconds
    source_sample_rate: Optional[int] = None  # Hz
    source_channels: Optional[int] = None
    source_lufs: Optional[float] = None  # Measured integrated loudness (LUFS)
    # Output options
    output_sample_rate: Optional[int] = None  # Override output sample rate (Hz); None = keep source
    # Job state
    status: JobStatus = JobStatus.PENDING
    progress: float = 0.0
    error_message: Optional[str] = None
    created_at: datetime = field(default_factory=datetime.now)
    
    @property
    def input_filename(self) -> str:
        return os.path.basename(self.input_path)
    
    @property
    def display_name(self) -> str:
        """Returns relative path if base_dir is set, otherwise just filename."""
        if self.base_dir:
            try:
                rel_path = os.path.relpath(self.input_path, self.base_dir)
                return rel_path
            except ValueError:
                # Different drives on Windows
                return self.input_filename
        return self.input_filename
    
    @property
    def output_filename(self) -> str:
        return os.path.basename(self.output_path)
    
    @property
    def bitrate_display(self) -> str:
        """Human-readable bitrate string. 'n/a' if unknown."""
        if self.source_bitrate is None:
            return "n/a"
        kbps = self.source_bitrate // 1000
        if kbps >= 1000:
            return f"{kbps // 1000}.{(kbps % 1000) // 100}M"
        return f"{kbps}k"
    
    @property
    def duration_display(self) -> str:
        """Human-readable duration string (M:SS or H:MM:SS)."""
        if self.source_duration is None or self.source_duration <= 0:
            return ""
        total_seconds = int(self.source_duration)
        hours = total_seconds // 3600
        minutes = (total_seconds % 3600) // 60
        seconds = total_seconds % 60
        if hours > 0:
            return f"{hours}:{minutes:02d}:{seconds:02d}"
        return f"{minutes}:{seconds:02d}"
    
    @property
    def sample_rate_display(self) -> str:
        """Human-readable sample rate string (e.g., '44.1', '48', '96'). 'n/a' if unknown."""
        if self.source_sample_rate is None or self.source_sample_rate <= 0:
            return "n/a"
        khz = self.source_sample_rate / 1000
        # Show decimal only if needed (44.1, 88.2, etc.)
        if khz == int(khz):
            return str(int(khz))
        return f"{khz:.1f}"
    
    @property
    def lufs_display(self) -> str:
        """Human-readable LUFS string."""
        if self.source_lufs is None:
            return ""
        return f"{self.source_lufs:.1f}"


class BatchProcessor:
    def __init__(self):
        self.jobs: List[ConversionJob] = []
        self._is_processing = False
    
    def is_duplicate(self, input_path: str) -> bool:
        normalized = os.path.normpath(input_path).lower()
        for job in self.jobs:
            if job.status in (JobStatus.PENDING, JobStatus.CONVERTING):
                if os.path.normpath(job.input_path).lower() == normalized:
                    return True
        return False
    
    def add_job(
        self,
        input_path: str,
        output_dir: str,
        format_name: str,
        quality_option: str,
        output_extension: str,
        base_dir: Optional[str] = None,
        loudness_target: Optional[float] = None,
        output_sample_rate: Optional[int] = None,
        source_format: Optional[str] = None,
        source_bitrate: Optional[int] = None,
        source_duration: Optional[float] = None,
        source_sample_rate: Optional[int] = None,
        source_channels: Optional[int] = None,
    ) -> Optional[ConversionJob]:
        if self.is_duplicate(input_path):
            return None
        
        input_name = Path(input_path).stem
        output_filename = f"{input_name}{output_extension}"
        output_path = str(Path(output_dir) / output_filename)

        # Check disk AND paths already claimed by jobs in the current queue
        existing_output_paths = {j.output_path for j in self.jobs}
        counter = 1
        while os.path.exists(output_path) or output_path in existing_output_paths:
            output_filename = f"{input_name}_{counter}{output_extension}"
            output_path = str(Path(output_dir) / output_filename)
            counter += 1
        
        job = ConversionJob(
            id=str(uuid.uuid4())[:8],
            input_path=input_path,
            output_path=output_path,
            format_name=format_name,
            quality_option=quality_option,
            base_dir=base_dir,
            loudness_target=loudness_target,
            output_sample_rate=output_sample_rate,
            source_format=source_format,
            source_bitrate=source_bitrate,
            source_duration=source_duration,
            source_sample_rate=source_sample_rate,
            source_channels=source_channels,
        )
        
        self.jobs.append(job)
        return job
    
    def remove_job(self, job_id: str) -> bool:
        for i, job in enumerate(self.jobs):
            if job.id == job_id and job.status == JobStatus.PENDING:
                self.jobs.pop(i)
                return True
        return False
    
    def clear_completed(self):
        """Remove only successfully completed jobs from the queue.
        Failed and cancelled jobs are kept so the user can see what went wrong."""
        self.jobs = [
            job for job in self.jobs
            if job.status != JobStatus.COMPLETE
        ]
    
    def clear_all(self):
        if not self._is_processing:
            self.jobs = []
    
    def get_pending_jobs(self) -> List[ConversionJob]:
        return [job for job in self.jobs if job.status == JobStatus.PENDING]
    
    def update_pending_jobs(
        self,
        format_name: str,
        quality_option: str,
        extension: str,
        loudness_target: Optional[float] = None,
        output_sample_rate: Optional[int] = None,
    ):
        """Update all pending jobs with new format/quality/loudness/sample-rate settings."""
        # Seed claimed_paths with all non-pending jobs' output paths so we
        # don't collide with files that are already converting or completed.
        claimed_paths = {
            job.output_path for job in self.jobs
            if job.status != JobStatus.PENDING
        }

        for job in self.jobs:
            if job.status != JobStatus.PENDING:
                continue

            job.format_name = format_name
            job.quality_option = quality_option
            job.loudness_target = loudness_target
            job.output_sample_rate = output_sample_rate

            # Recompute output path with new extension
            input_name = Path(job.input_path).stem
            output_dir = str(Path(job.output_path).parent)
            new_output_filename = f"{input_name}{extension}"
            new_output_path = str(Path(output_dir) / new_output_filename)

            # Handle collision: check disk AND paths already claimed by sibling jobs
            counter = 1
            while (
                (os.path.exists(new_output_path) or new_output_path in claimed_paths)
                and new_output_path != job.output_path
            ):
                new_output_filename = f"{input_name}_{counter}{extension}"
                new_output_path = str(Path(output_dir) / new_output_filename)
                counter += 1

            claimed_paths.add(new_output_path)
            job.output_path = new_output_path
    
    def get_job_by_id(self, job_id: str) -> Optional[ConversionJob]:
        for job in self.jobs:
            if job.id == job_id:
                return job
        return None
    
    @property
    def is_processing(self) -> bool:
        return self._is_processing
    
    @property
    def pending_count(self) -> int:
        return len(self.get_pending_jobs())
    
    def request_cancel(self):
        # Cancellation state is managed by BatchWorker, not BatchProcessor.
        # This method is kept for API compatibility.
        pass
    
    def get_summary(self) -> dict:
        summary = {status: 0 for status in JobStatus}
        for job in self.jobs:
            summary[job.status] += 1
        return {
            "pending": summary[JobStatus.PENDING],
            "converting": summary[JobStatus.CONVERTING],
            "complete": summary[JobStatus.COMPLETE],
            "failed": summary[JobStatus.FAILED],
            "cancelled": summary[JobStatus.CANCELLED],
            "total": len(self.jobs),
        }
