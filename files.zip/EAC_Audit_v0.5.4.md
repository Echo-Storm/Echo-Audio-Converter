# Echo Audio Converter v0.5.4 — Fourth Audit Report

---

## BAT1 — `EchoAudioConverter.bat` — Opens, checks, closes without starting (user-reported)

**Severity:** High — app unusable via launcher

Two compounding problems introduced in v0.5.4:

**Problem A — pip runs on every launch.**  
The P4 fix moved `pip install` outside the venv-creation block so it runs
unconditionally on every start. On an existing install, pip contacts PyPI or
checks the local cache, exits, and the window moves on. This is the "doing a
check" the user sees. This is fragile — any pip issue (network hiccup,
corrupted cache, version warning treated as error) silently kills startup.

**Problem B — no error handling after `python echo_audio_converter.py`.**  
If Python exits with errorlevel 1 (import error, crash on startup, any
exception before the window appears), the bat just ends — window closes, user
sees nothing. This was missing from every version of the bat.

**Fix:** Revert pip to first-install-only (correct original behavior). Add
`if errorlevel 1` after the python call so startup crashes show an actionable
message and keep the window open.

---

## Q1 — `main_window.py` — Queue summary label never shows cancelled count

**Severity:** Low — cosmetic, minor UX inconsistency

```python
if summary['pending'] > 0:
    parts.append(f"{summary['pending']} pending")
if summary['complete'] > 0:
    parts.append(f"{summary['complete']} complete")
if summary['failed'] > 0:
    parts.append(f"{summary['failed']} failed")
# ← cancelled never shown
```

After a cancelled batch the label reads something like "2 complete" with no
mention of the cancelled jobs. The status bar message (from `_on_batch_finished`)
does say "N cancelled", but once that clears after 5 seconds the summary label
gives no indication. A user looking at the queue later won't know which jobs
were cancelled vs. just not run.

**Fix:** Add the cancelled count alongside the others.

---

## SUMMARY

| ID | File | Severity | Description |
|----|------|----------|-------------|
| BAT1 | EchoAudioConverter.bat | High | pip on every launch + no error catch after python = silent close on failure |
| Q1 | main_window.py | Low | Queue summary label never shows cancelled job count |

**The Python codebase is otherwise clean.** All previous medium/high severity
bugs are resolved. No crashes, no data-loss paths, no bare excepts, no dead
code remain.
